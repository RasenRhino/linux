#/bin/bash
function weather-pull {
	while true 
	do
		curl "http://wttr.in/11.273904, 76.314262?T&1&Q&F&lang=en" --silent --max-time 3 > /tmp/weather.tmp
		sleep 1200	
	done
}
weather-pull
